//
//  UIColor Properties.swift
//  Course2FinalTask
//
//  Created by Aleksey Bardin on 11.03.2020.
//  Copyright © 2020 Bardincom. All rights reserved.
//

import UIKit

let lightGrayColor = UIColor(named: "lightGrayColor")
let defaultTintColor =  UIColor(named: "defaultTintColor")
let viewBackgroundColor = UIColor(named: "viewBackgroundColor")
