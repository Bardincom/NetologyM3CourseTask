//
//  UIColor Properties.swift
//  Course2FinalTask
//
//  Created by Aleksey Bardin on 11.03.2020.
//  Copyright © 2020 Bardincom. All rights reserved.
//

import UIKit

let lightGrayColor: UIColor = .lightGray
let defaultTintColor: UIColor? = nil


    
