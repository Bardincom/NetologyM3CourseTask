//
//  UIFont Properties.swift
//  Course2FinalTask
//
//  Created by Aleksey Bardin on 11.03.2020.
//  Copyright © 2020 Bardincom. All rights reserved.
//

import UIKit


let systemsBoldFont: UIFont = .systemFont(ofSize: 14, weight: .semibold)
let systemsFont: UIFont = .systemFont(ofSize: 14)
